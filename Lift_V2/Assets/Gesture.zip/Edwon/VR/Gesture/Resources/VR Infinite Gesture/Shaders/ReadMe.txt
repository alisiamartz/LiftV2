in this folder are two default unity shaders 
that we use to render gesture recordings in the gesture edit mode, 
as well as rendering a line while you detect gestures

if you don't have these shaders in a resources folder,
you won't be able to use our built in VR UI for VR Gesture Tracker,
but you may not need it, it's up to you

if you don't want to use our VR UI and don't need/want these shaders in your build,
go ahead and delete this resources folder and it's contents