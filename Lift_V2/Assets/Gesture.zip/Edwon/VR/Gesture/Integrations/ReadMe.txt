
VR Infinite Gesture
Integrations ReadMe

For Playmaker support:

1. Import Playmaker from the Unity Asset Store

2. Install Playmaker

3. Import the "Playmaker" package located in this folder.

4. Open the "Playmaker Example" scene to see how to use Playmaker with VR Gesture Tracker